<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>PHP Mail</title>
</head>
<body>
    <div class="main">
    <div class="mail-area">
        <h1>PHP Mail</h1>
        <form>
            <input type="text" class="input" placeholder="Email Id">
            <textarea class="input" placeholder="Message"></textarea>
            <input type="file" class="up">
            <input class="input btn" type="submit" value="Send">
        </form>
    </div>
    </div>
</body>
</html>